# ortho_4x12

A wide, split layout for use on grid Planck or Let's Split based on the Colemak Mod-DH keyboard layout.

![layout image](https://i.imgur.com/y3O6U1R.png)
