# Jotix ortho 4x12 keymap

Tested on:

* Planck/rev4
* Jotanck
