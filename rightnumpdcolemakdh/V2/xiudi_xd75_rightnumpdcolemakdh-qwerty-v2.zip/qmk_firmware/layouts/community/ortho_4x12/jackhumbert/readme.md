![Jack's Planck Keymap](https://i.imgur.com/763RLNC.png)

# Jack's Planck Keymap

[Link to KLE of above image](http://www.keyboard-layout-editor.com/#/gists/8d5e8d5ee3884333bc5c4a231035f145)

Mostly standard Colemak, but the shift and symbol layers are influenced from BEAKL: https://ieants.cc/code/keyboard/beakl/

Unfortunately I haven't figured out a good way to adapt this to a 2u format yet.