This folder contains my [4x12\_ortho](../../../default/ortho_4x12) board layouts
Check out the [user readme](../../../../users/bbaserdem/readme.md) for more info.

# Planck Light

I use a couple [planck](../../../../keyboards/planck/readme.md) keyboards.
To sell soon; don't use them anymore, but will keep the light version.

# JJ40

A planck rev4 replacement; for my acrylic planck case which used to host a now
defunct rev4.
