# 寻求帮助

<!---
  original document: 0.15.12:docs/support.md
  git diff 0.15.12 HEAD -- docs/support.md | cat
-->

你可以从很多渠道获取QMK帮助。

在你前往社区进行沟通前，请先阅览我们的社区[行为守则](https://qmk.fm/coc/)

## 实时沟通

在你需要帮助时，最便捷的办法是通过我们的[Discord服务器](https://discord.gg/Uq7gcHh)进行沟通，通常会有人在线，也有很多乐于助人的人。

## OLKB Subreddit

QMK的官方论坛是[reddit.com](https://reddit.com)上的[/r/olkb](https://reddit.com/r/olkb).

## GitHub Issues

你可以在[Github上发Issue](https://github.com/qmk/qmk_firmware/issues)，对于需要深入讨论或需要调试的问题，会方便得多。
